import { configureStore } from "@reduxjs/toolkit";
// import ProfileTabSlice from "./slices/profileTabSlice";
// import Profiledata from "./slices/profiledata";
// import userSlice from "./slices/userSlice";
// import panDetailSlice from "./slices/panDetailSlice";
// import gstNumbersSlice from "./slices/gstNumberSlice";
// import entityDetailsSlice from "./slices/entityDetailSlice";
// import Approve_InvoicesSlice from "./slices/investor/approveInvoice";
// import Invested_InvoiceSlice from "./slices/investor/investedInvoice";
// import PendingInvested_InvoiceSlice from "./slices/investor/pendingInvestedInvoice";
// import MyInvoiceDataForMobileSlice from "./slices/investor/myInvoiceDataForMobile";
// import BuyInvoiceAmountSlice from "./slices/investor/buyInvoiceAmount";

export default configureStore({
  reducer: {
    // ProfileTab: ProfileTabSlice,
    // ProfileData: Profiledata,
    // Users: userSlice,
    // PanDetails: panDetailSlice,
    // GstNumbers: gstNumbersSlice,
    // EntityDetails: entityDetailsSlice,
    // ApproveInvoices: Approve_InvoicesSlice,
    // InvestedInvoice: Invested_InvoiceSlice,
    // PendingInvestedInvoice: PendingInvested_InvoiceSlice,
    // MyInVoiceDataForMobile: MyInvoiceDataForMobileSlice,
    // BuyInvoiceAmount: BuyInvoiceAmountSlice,
  },
});
