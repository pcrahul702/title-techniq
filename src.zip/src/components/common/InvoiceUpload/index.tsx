import Scfcommonbutton from 'src/components/common/Button/scfcommonbutton';

interface PropTypes {
  wrapperClass?: string;
}
export default function InvoiceUpload({ wrapperClass }: PropTypes) {
  return <></>;
}
