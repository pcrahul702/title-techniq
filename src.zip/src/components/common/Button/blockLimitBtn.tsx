export default function BlockLimitBtn() {
  return (
    <>
      <div className='bg-white border border-black rounded-[20px]'>
        <p className='text-steelBlue p-1'>Request for Block Limit</p>
      </div>
    </>
  );
}
